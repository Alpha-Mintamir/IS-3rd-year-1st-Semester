﻿namespace LEARASHU
{
    partial class Farmer_Create_account_Step2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Farmer_Create_account_Step2));
            this.topPanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.EbtnSuperHome = new System.Windows.Forms.PictureBox();
            this.logoPanel = new System.Windows.Forms.Panel();
            this.finishRegButton = new System.Windows.Forms.Button();
            this.proofDocUploadBtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.profileUploadBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.profilePictureBox = new System.Windows.Forms.PictureBox();
            this.CoverPictureBox = new System.Windows.Forms.PictureBox();
            this.coverUploadButton = new System.Windows.Forms.Button();
            this.proofDocTextBox = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.topPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EbtnSuperHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CoverPictureBox)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // topPanel
            // 
            this.topPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(35)))), ((int)(((byte)(126)))));
            this.topPanel.Controls.Add(this.label1);
            this.topPanel.Controls.Add(this.EbtnSuperHome);
            this.topPanel.Controls.Add(this.logoPanel);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.topPanel.Location = new System.Drawing.Point(0, 0);
            this.topPanel.Margin = new System.Windows.Forms.Padding(0);
            this.topPanel.Name = "topPanel";
            this.topPanel.Size = new System.Drawing.Size(1463, 72);
            this.topPanel.TabIndex = 4;
            this.topPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.topPanel_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(117, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 48);
            this.label1.TabIndex = 8;
            this.label1.Text = "ለአራሹ";
            // 
            // EbtnSuperHome
            // 
            this.EbtnSuperHome.Image = ((System.Drawing.Image)(resources.GetObject("EbtnSuperHome.Image")));
            this.EbtnSuperHome.Location = new System.Drawing.Point(3, 12);
            this.EbtnSuperHome.Margin = new System.Windows.Forms.Padding(0);
            this.EbtnSuperHome.Name = "EbtnSuperHome";
            this.EbtnSuperHome.Size = new System.Drawing.Size(71, 43);
            this.EbtnSuperHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.EbtnSuperHome.TabIndex = 7;
            this.EbtnSuperHome.TabStop = false;
            // 
            // logoPanel
            // 
            this.logoPanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.logoPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logoPanel.BackgroundImage")));
            this.logoPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.logoPanel.Location = new System.Drawing.Point(1320, 3);
            this.logoPanel.Name = "logoPanel";
            this.logoPanel.Size = new System.Drawing.Size(140, 67);
            this.logoPanel.TabIndex = 2;
            // 
            // finishRegButton
            // 
            this.finishRegButton.BackColor = System.Drawing.Color.Cyan;
            this.finishRegButton.FlatAppearance.BorderSize = 0;
            this.finishRegButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.finishRegButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.finishRegButton.ForeColor = System.Drawing.Color.White;
            this.finishRegButton.Location = new System.Drawing.Point(1154, 325);
            this.finishRegButton.Name = "finishRegButton";
            this.finishRegButton.Size = new System.Drawing.Size(179, 85);
            this.finishRegButton.TabIndex = 121;
            this.finishRegButton.Text = "Finish Registration";
            this.finishRegButton.UseVisualStyleBackColor = false;
            this.finishRegButton.Click += new System.EventHandler(this.finishRegButton_Click);
            // 
            // proofDocUploadBtn
            // 
            this.proofDocUploadBtn.BackColor = System.Drawing.Color.Red;
            this.proofDocUploadBtn.FlatAppearance.BorderSize = 0;
            this.proofDocUploadBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.proofDocUploadBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.proofDocUploadBtn.ForeColor = System.Drawing.Color.White;
            this.proofDocUploadBtn.Location = new System.Drawing.Point(873, 618);
            this.proofDocUploadBtn.Name = "proofDocUploadBtn";
            this.proofDocUploadBtn.Size = new System.Drawing.Size(134, 40);
            this.proofDocUploadBtn.TabIndex = 120;
            this.proofDocUploadBtn.Text = "Upload";
            this.proofDocUploadBtn.UseVisualStyleBackColor = false;
            this.proofDocUploadBtn.Click += new System.EventHandler(this.proofDocUploadBtn_Click);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(445, 559);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(354, 36);
            this.label5.TabIndex = 119;
            this.label5.Text = "Upload Proof Document";
            // 
            // profileUploadBtn
            // 
            this.profileUploadBtn.BackColor = System.Drawing.Color.Red;
            this.profileUploadBtn.FlatAppearance.BorderSize = 0;
            this.profileUploadBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.profileUploadBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileUploadBtn.ForeColor = System.Drawing.Color.White;
            this.profileUploadBtn.Location = new System.Drawing.Point(873, 441);
            this.profileUploadBtn.Name = "profileUploadBtn";
            this.profileUploadBtn.Size = new System.Drawing.Size(134, 40);
            this.profileUploadBtn.TabIndex = 118;
            this.profileUploadBtn.Text = "Upload";
            this.profileUploadBtn.UseVisualStyleBackColor = false;
            this.profileUploadBtn.Click += new System.EventHandler(this.profileUploadBtn_Click);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(445, 300);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(327, 36);
            this.label4.TabIndex = 117;
            this.label4.Text = "Upload Profile Picture";
            // 
            // profilePictureBox
            // 
            this.profilePictureBox.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.profilePictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.profilePictureBox.Location = new System.Drawing.Point(506, 369);
            this.profilePictureBox.Name = "profilePictureBox";
            this.profilePictureBox.Size = new System.Drawing.Size(173, 170);
            this.profilePictureBox.TabIndex = 116;
            this.profilePictureBox.TabStop = false;
            // 
            // CoverPictureBox
            // 
            this.CoverPictureBox.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.CoverPictureBox.Location = new System.Drawing.Point(333, 140);
            this.CoverPictureBox.Name = "CoverPictureBox";
            this.CoverPictureBox.Size = new System.Drawing.Size(493, 136);
            this.CoverPictureBox.TabIndex = 115;
            this.CoverPictureBox.TabStop = false;
            // 
            // coverUploadButton
            // 
            this.coverUploadButton.BackColor = System.Drawing.Color.Red;
            this.coverUploadButton.FlatAppearance.BorderSize = 0;
            this.coverUploadButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.coverUploadButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coverUploadButton.ForeColor = System.Drawing.Color.White;
            this.coverUploadButton.Location = new System.Drawing.Point(873, 195);
            this.coverUploadButton.Name = "coverUploadButton";
            this.coverUploadButton.Size = new System.Drawing.Size(134, 40);
            this.coverUploadButton.TabIndex = 114;
            this.coverUploadButton.Text = "Upload";
            this.coverUploadButton.UseVisualStyleBackColor = false;
            this.coverUploadButton.Click += new System.EventHandler(this.coverUploadButton_Click);
            // 
            // proofDocTextBox
            // 
            this.proofDocTextBox.Location = new System.Drawing.Point(506, 628);
            this.proofDocTextBox.Name = "proofDocTextBox";
            this.proofDocTextBox.Size = new System.Drawing.Size(196, 27);
            this.proofDocTextBox.TabIndex = 113;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1463, 685);
            this.panel1.TabIndex = 122;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(430, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(319, 36);
            this.label3.TabIndex = 107;
            this.label3.Text = "Upload Cover Picture";
            // 
            // Farmer_Create_account_Step2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1463, 685);
            this.Controls.Add(this.finishRegButton);
            this.Controls.Add(this.proofDocUploadBtn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.profileUploadBtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.profilePictureBox);
            this.Controls.Add(this.CoverPictureBox);
            this.Controls.Add(this.coverUploadButton);
            this.Controls.Add(this.proofDocTextBox);
            this.Controls.Add(this.topPanel);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Farmer_Create_account_Step2";
            this.Text = "Farmer_Create_account_Step2";
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EbtnSuperHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CoverPictureBox)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox EbtnSuperHome;
        private System.Windows.Forms.Panel logoPanel;
        private System.Windows.Forms.Button finishRegButton;
        private System.Windows.Forms.Button proofDocUploadBtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button profileUploadBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox profilePictureBox;
        private System.Windows.Forms.PictureBox CoverPictureBox;
        private System.Windows.Forms.Button coverUploadButton;
        private System.Windows.Forms.TextBox proofDocTextBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
    }
}