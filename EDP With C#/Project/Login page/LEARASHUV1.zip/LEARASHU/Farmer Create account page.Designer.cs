﻿namespace LEARASHU
{
    partial class Farmer_Create_account_page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.topPanel = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.LastNameTextBox = new System.Windows.Forms.TextBox();
            this.birthDate = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.EproductComboBox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.EareaComboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.EregionComboBox = new System.Windows.Forms.ComboBox();
            this.EregionLbl = new System.Windows.Forms.Label();
            this.EfemaleRadioButton = new System.Windows.Forms.RadioButton();
            this.EmaleRadioButton = new System.Windows.Forms.RadioButton();
            this.EgenderRadiolbl = new System.Windows.Forms.Label();
            this.showPasswordCheckBox1 = new System.Windows.Forms.CheckBox();
            this.EemailTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.EpasswordTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.EphoneNumTextBox = new System.Windows.Forms.TextBox();
            this.EfirstNameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.topPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // topPanel
            // 
            this.topPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(35)))), ((int)(((byte)(126)))));
            this.topPanel.Controls.Add(this.label3);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.topPanel.Location = new System.Drawing.Point(0, 0);
            this.topPanel.Name = "topPanel";
            this.topPanel.Size = new System.Drawing.Size(1171, 72);
            this.topPanel.TabIndex = 19;
            this.topPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.topPanel_Paint);
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(143, 182);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 29);
            this.label12.TabIndex = 66;
            this.label12.Text = "Last Name";
            // 
            // LastNameTextBox
            // 
            this.LastNameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LastNameTextBox.Location = new System.Drawing.Point(359, 184);
            this.LastNameTextBox.Name = "LastNameTextBox";
            this.LastNameTextBox.Size = new System.Drawing.Size(157, 27);
            this.LastNameTextBox.TabIndex = 65;
            // 
            // birthDate
            // 
            this.birthDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.birthDate.Location = new System.Drawing.Point(359, 261);
            this.birthDate.Name = "birthDate";
            this.birthDate.Size = new System.Drawing.Size(160, 27);
            this.birthDate.TabIndex = 64;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(897, 214);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 29);
            this.label11.TabIndex = 63;
            this.label11.Text = "Address";
            // 
            // EproductComboBox
            // 
            this.EproductComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EproductComboBox.FormattingEnabled = true;
            this.EproductComboBox.Items.AddRange(new object[] {
            "Coffee(Buna)",
            "khat(chat)",
            "Selit"});
            this.EproductComboBox.Location = new System.Drawing.Point(996, 403);
            this.EproductComboBox.Name = "EproductComboBox";
            this.EproductComboBox.Size = new System.Drawing.Size(157, 28);
            this.EproductComboBox.TabIndex = 62;
            this.EproductComboBox.Text = "Select";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(815, 399);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 29);
            this.label10.TabIndex = 61;
            this.label10.Text = " Product";
            // 
            // EareaComboBox
            // 
            this.EareaComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EareaComboBox.FormattingEnabled = true;
            this.EareaComboBox.Location = new System.Drawing.Point(996, 333);
            this.EareaComboBox.Name = "EareaComboBox";
            this.EareaComboBox.Size = new System.Drawing.Size(157, 28);
            this.EareaComboBox.TabIndex = 60;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(815, 329);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 29);
            this.label9.TabIndex = 59;
            this.label9.Text = "Area";
            // 
            // EregionComboBox
            // 
            this.EregionComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EregionComboBox.FormattingEnabled = true;
            this.EregionComboBox.Items.AddRange(new object[] {
            "Amhara",
            "Oromia",
            "Sidama",
            "SNNPR"});
            this.EregionComboBox.Location = new System.Drawing.Point(996, 263);
            this.EregionComboBox.Name = "EregionComboBox";
            this.EregionComboBox.Size = new System.Drawing.Size(157, 28);
            this.EregionComboBox.TabIndex = 58;
            this.EregionComboBox.SelectedIndexChanged += new System.EventHandler(this.EregionComboBox_SelectedIndexChanged_1);
            // 
            // EregionLbl
            // 
            this.EregionLbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EregionLbl.AutoSize = true;
            this.EregionLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EregionLbl.Location = new System.Drawing.Point(815, 259);
            this.EregionLbl.Name = "EregionLbl";
            this.EregionLbl.Size = new System.Drawing.Size(91, 29);
            this.EregionLbl.TabIndex = 57;
            this.EregionLbl.Text = "Region";
            // 
            // EfemaleRadioButton
            // 
            this.EfemaleRadioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EfemaleRadioButton.AutoSize = true;
            this.EfemaleRadioButton.Location = new System.Drawing.Point(996, 154);
            this.EfemaleRadioButton.Name = "EfemaleRadioButton";
            this.EfemaleRadioButton.Size = new System.Drawing.Size(85, 24);
            this.EfemaleRadioButton.TabIndex = 56;
            this.EfemaleRadioButton.TabStop = true;
            this.EfemaleRadioButton.Text = "Female";
            this.EfemaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // EmaleRadioButton
            // 
            this.EmaleRadioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmaleRadioButton.AutoSize = true;
            this.EmaleRadioButton.Location = new System.Drawing.Point(924, 154);
            this.EmaleRadioButton.Name = "EmaleRadioButton";
            this.EmaleRadioButton.Size = new System.Drawing.Size(66, 24);
            this.EmaleRadioButton.TabIndex = 55;
            this.EmaleRadioButton.TabStop = true;
            this.EmaleRadioButton.Text = "Male";
            this.EmaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // EgenderRadiolbl
            // 
            this.EgenderRadiolbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EgenderRadiolbl.AutoSize = true;
            this.EgenderRadiolbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EgenderRadiolbl.Location = new System.Drawing.Point(815, 151);
            this.EgenderRadiolbl.Name = "EgenderRadiolbl";
            this.EgenderRadiolbl.Size = new System.Drawing.Size(94, 29);
            this.EgenderRadiolbl.TabIndex = 54;
            this.EgenderRadiolbl.Text = "Gender";
            // 
            // showPasswordCheckBox1
            // 
            this.showPasswordCheckBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.showPasswordCheckBox1.AutoSize = true;
            this.showPasswordCheckBox1.Location = new System.Drawing.Point(525, 492);
            this.showPasswordCheckBox1.Name = "showPasswordCheckBox1";
            this.showPasswordCheckBox1.Size = new System.Drawing.Size(72, 24);
            this.showPasswordCheckBox1.TabIndex = 53;
            this.showPasswordCheckBox1.Text = "Show";
            this.showPasswordCheckBox1.UseVisualStyleBackColor = true;
            this.showPasswordCheckBox1.CheckedChanged += new System.EventHandler(this.showPasswordCheckBox1_CheckedChanged_1);
            // 
            // EemailTextBox
            // 
            this.EemailTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EemailTextBox.Location = new System.Drawing.Point(359, 413);
            this.EemailTextBox.Name = "EemailTextBox";
            this.EemailTextBox.Size = new System.Drawing.Size(157, 27);
            this.EemailTextBox.TabIndex = 52;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(639, 523);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(201, 20);
            this.label5.TabIndex = 50;
            this.label5.Text = "Already have an account?";
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(111)))), ((int)(((byte)(0)))));
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(644, 545);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(158, 45);
            this.button2.TabIndex = 49;
            this.button2.Text = "Login";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(111)))), ((int)(((byte)(0)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(422, 545);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(158, 45);
            this.button1.TabIndex = 48;
            this.button1.Text = "Create Account";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // EpasswordTextBox
            // 
            this.EpasswordTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EpasswordTextBox.Location = new System.Drawing.Point(359, 486);
            this.EpasswordTextBox.Name = "EpasswordTextBox";
            this.EpasswordTextBox.PasswordChar = '*';
            this.EpasswordTextBox.Size = new System.Drawing.Size(157, 27);
            this.EpasswordTextBox.TabIndex = 47;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(143, 486);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 29);
            this.label4.TabIndex = 46;
            this.label4.Text = "Password";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(143, 409);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 29);
            this.label2.TabIndex = 44;
            this.label2.Text = "Email Address";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(143, 341);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(176, 29);
            this.label8.TabIndex = 43;
            this.label8.Text = "Phone Number";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(143, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(144, 29);
            this.label7.TabIndex = 42;
            this.label7.Text = "Date of Birth\r\n";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(143, 118);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 29);
            this.label6.TabIndex = 41;
            this.label6.Text = "First Name";
            // 
            // EphoneNumTextBox
            // 
            this.EphoneNumTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EphoneNumTextBox.Location = new System.Drawing.Point(359, 345);
            this.EphoneNumTextBox.Name = "EphoneNumTextBox";
            this.EphoneNumTextBox.Size = new System.Drawing.Size(157, 27);
            this.EphoneNumTextBox.TabIndex = 39;
            // 
            // EfirstNameTextBox
            // 
            this.EfirstNameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EfirstNameTextBox.Location = new System.Drawing.Point(359, 120);
            this.EfirstNameTextBox.Name = "EfirstNameTextBox";
            this.EfirstNameTextBox.Size = new System.Drawing.Size(157, 27);
            this.EfirstNameTextBox.TabIndex = 38;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(520, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 29);
            this.label1.TabIndex = 37;
            this.label1.Text = "Create Account";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(34, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(451, 36);
            this.label3.TabIndex = 13;
            this.label3.Text = "Farmer Account Creation Page";
            // 
            // Farmer_Create_account_page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 593);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.topPanel);
            this.Controls.Add(this.LastNameTextBox);
            this.Controls.Add(this.EemailTextBox);
            this.Controls.Add(this.birthDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.EfirstNameTextBox);
            this.Controls.Add(this.EproductComboBox);
            this.Controls.Add(this.EphoneNumTextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.EareaComboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.EregionComboBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.EregionLbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.EfemaleRadioButton);
            this.Controls.Add(this.EmaleRadioButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.EgenderRadiolbl);
            this.Controls.Add(this.EpasswordTextBox);
            this.Controls.Add(this.showPasswordCheckBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Farmer_Create_account_page";
            this.Text = "Farmer_Create_account_page";
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox LastNameTextBox;
        private System.Windows.Forms.DateTimePicker birthDate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox EproductComboBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox EareaComboBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox EregionComboBox;
        private System.Windows.Forms.Label EregionLbl;
        private System.Windows.Forms.RadioButton EfemaleRadioButton;
        private System.Windows.Forms.RadioButton EmaleRadioButton;
        private System.Windows.Forms.Label EgenderRadiolbl;
        private System.Windows.Forms.CheckBox showPasswordCheckBox1;
        private System.Windows.Forms.TextBox EemailTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox EpasswordTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox EphoneNumTextBox;
        private System.Windows.Forms.TextBox EfirstNameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
    }
}