
var btn = document.getElementById("exporter_create_account");


        
        btn.addEventListener("click", function() {
            
            window.location.href = "/Assets/exporter_login.html";
        });