

var btn = document.getElementById("login_btn");

        
        btn.addEventListener("click", function() {
            
            window.location.href = "/Assets/exporter_dashboard.html";
        });