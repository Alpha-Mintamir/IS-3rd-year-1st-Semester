
var btn = document.getElementById("farmer_create_account");


        
        btn.addEventListener("click", function() {
            
            window.location.href = "/Assets/farmer_login.html";
        });