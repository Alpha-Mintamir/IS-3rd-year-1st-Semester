var btn = document.getElementById("login_btn")

var btn = document.getElementById("login_btn");

        
        btn.addEventListener("click", function() {
            
            window.location.href = "/Assets/farmer_dashboard.html";
        });